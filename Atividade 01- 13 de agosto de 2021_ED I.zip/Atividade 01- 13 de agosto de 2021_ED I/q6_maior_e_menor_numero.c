#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia 2(dois) n�meros, verifique e escreva o menor e o maior
entre os n�meros lidos.
*/

int main()
{
		int num_1, num_2, diff;
		
		printf("Escreva o primeiro n�mero: ");
		scanf("%d", &num_1);
		printf("Escreva o segundo n�mero: ");
		scanf("%d", &num_2);
		
		if (num_1 > num_2)
		{
			diff = (num_1 - num_2);
			printf("N�mero 1 � maior.");
		}
		else if (num_1 < num_2)
		{
			diff = (num_2 - num_1);
			printf("N�mero 2 � maior.");
		}
		else if (num_1 == num_2)
		{
			diff = 0;
			printf("Haver� valor nulo em ambas as partes.");
		}
		system("PAUSE");
}
		
		
		
