#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia o valor do d�lar e um valor em d�lar, calcule e
escreva o equivalente em real(R$). Trata-se de uma cota��o.
*/

main()
{
	
	float valor_dolar, quant_dolar, valor_real;
	
	printf("Digite aqui quanto vale o d�lar: ");
	scanf("%f",&valor_dolar);
	printf("Digite aqui quantos d�lares ser�o convertidos: ");
	scanf("%f",&quant_dolar);
	
	valor_real = (valor_dolar * quant_dolar);
	printf("A cota��o do d�lar ou valor de moeda valer� em reais R$: %f", valor_real);
	system("PAUSE");
	
}
