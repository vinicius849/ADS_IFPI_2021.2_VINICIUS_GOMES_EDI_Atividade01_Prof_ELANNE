#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia 2(duas) notas de um aluno e escreva na tela a palavra "Aprovado" se a m�dia das duas notas
for maior ou igual a 7.0. Caso a m�dia seja inferior a 7.0, escreva "O aluno deve fazer a Prova Final!"
e o programa deve ler a nota da Prova Final e calcule a M�dia Final. Se a m�dia final for maior ou igual
a 6.0, o programa deve escrever "Aprovado!", caso contr�rio deve escrever "Reprovado!".
*/

main()
{
	float nota_1, nota_2, media_final;
	
	printf("Digite aqui a primeira nota: ");
	scanf("%f", &nota_1);
	printf("Digite aqui a segunda nota: ");
	scanf("%f", &nota_2);
	
	media_final = (nota_1 + nota_2) / 2;
	printf("Com isso, sua M�dia Final no col�gio ser� %2f ", media_final);
	
	if (media_final >= 7.0){
	printf("APROVADO");
	}else if (media_final < 7.0){
		printf("O aluno deve fazer a Prova Final");
	}else if (media_final >= 6.0){
		printf("APROVADO!");
	}else{
		printf("REPROVADO");
	}
}
