#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia uma velocidade em m/s, calcule e escreva 
esta velocidade em km/h. (Vkm/h = Vm/s * 3.6)
*/

main()
{

	float vel_ms, vel_kmh;
	
	printf("Digite aqui a velocidade em m/s por gentileza: ");
	scanf("%f",&vel_ms);
	printf("Digite aqui a velocidade em km/h por gentileza: ");
	scanf("%f",&vel_kmh);
	
	vel_kmh = (vel_ms * 3.6);
	printf("A velocidade convertida ser� igual a %2f: ",vel_kmh,"quil�metros por hora.");
	system("PAUSE");
	
}
	
	
