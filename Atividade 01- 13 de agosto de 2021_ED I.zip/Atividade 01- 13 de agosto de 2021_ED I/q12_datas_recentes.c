#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia duas datas(cada data � composta por 3 vari�veis
 inteiras: dia, m�s e ano) e escreva qual delas 
� a mais recente.
*/

int main()
{
	int dia_1, dia_2, mes_1, mes_2, ano_1, ano_2;
	
	printf("Digite para o primeiro dia: ");
	scanf("%d", &dia_1);
	printf("Digite aqui o primeiro m�s: ");
	scanf("%d", &mes_1);
	printf("Digite aqui o primeiro ano: ");
	scanf("%d", &ano_1);
	
	printf("Digite aqui o segundo dia: ");
	scanf("%d", &dia_2);
	printf("Digite aqui o segundo m�s: ");
	scanf("%d", &mes_2);
	print("Digite aqui o segundo ano: ");
	scanf("%d", &ano_2);
	
	if (ano_1 > ano_2) {
		printf("% d / % d / % d" � um dado mais recente / n / n, dia_1, mes_1, ano_1);
	}else if (ano_2 > ano_1) {
		printf("% d / % d / % d" � um dado mais recente / n / n, dia_2, mes_2, ano_2);
	}else if (ano_1 == ano_2) {
		if (mes_1 > mes_2) {
			printf(" % d / % d / % d" � um dado recente / n / n, dia_1, mes_1 , ano_1);
	}else if (mes_2 > mes_1) {
		printf(" % d / % d / % d" � um dado recente / n / n, dia_2, mes_2, ano_2);
	}else if (mes_1 == mes_2) {
		if (dia_1 > dia_2) {
			printf(" % d / % d / % d" � um dado recente / n / n, dia_1, mes_1, ano_1);
	}else if (dia_2 > dia_1) {
		printf(" % d / % d/ % d " � um dado recente / n / n, dia_2, mes_2, ano_2);
	}else {
		prinf("As datas s�o iguais! / n / n ");
	}
	}
	}
}
