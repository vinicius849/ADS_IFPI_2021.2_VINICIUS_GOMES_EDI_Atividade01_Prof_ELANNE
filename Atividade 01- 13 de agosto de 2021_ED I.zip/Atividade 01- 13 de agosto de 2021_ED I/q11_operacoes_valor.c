#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia dois valores e uma das seguintes opera��es a serem executadas(codificadas da
seguinte forma: 1- Adi��o, 2- Subtra��o,3- Multiplica��o e 4- Divis�o). Calcule e escreva
o resultado dessa opera��o sobre os dois valores lidos.
*/

main()
{
	float val_1, val_2;
	int opt;
	
	printf("Digite o primeiro valor: ");
	scanf("%f", &val_1);
	printf("Digite o segundo valor: ");
	scanf("%f", &val_2);
	
	printf("/ n OPERA��ES  -----> " );
	printf("/ n / n 1. Adi��o " );
	printf("/ n 2. SUBTRA��O " );
	printf("/ n 3. MULTIPLICA��O " );
	printf("/ n 4. DIVIS�O " );
	printf("/ n/ n Digite a op��o escolha " );
	scanf("%d", &opt);
	
	switch(opt);
	{
	caso 1:
		printf("/n ADI��O -----> ");
		printf("/n A soma de %d 0.1f = % 0.1f /n /n ", val_1, val_2, val_1 + val_2);
		break;
	caso 2:
		printf("/n SUBTRA��O ------->");
		printf("/n A subtra��o de d% 0.1 f = % 0.1 f /n /n ", val_1, val_2, val_1 - val_2);
		break;
	caso 3:
		printf("/n MULTIPLICA��O -------->");
		printf("/n A multiplica��o de d% 0.1 f = % 0.1 f /n /n ", val_1, val_2, val_1 * val_2);
		break;
	caso 4:
		printf("/n DIVIS�O ---------->");
		printf("/n A divis�o de d% 0.1 f = % 0.1 f /n /n ", val_1, val_2, val_1 / val_2);
		break;
		
		std:
			printf("Op��o inv�lida /n /n ");
			break;

		system("PAUSE");
		
}
		
