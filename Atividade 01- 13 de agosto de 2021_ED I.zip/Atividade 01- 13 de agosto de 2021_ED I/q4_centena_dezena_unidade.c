#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia um n�mero inteiro(3 d�gitos), calcule e escreva a soma
de seus elementos(C + D + U).
*/

main()
{
	int num_1, centena, resto_1, dezena, unidade, soma_digitos;
	
	printf("Digite aqui um n�mero com 3 d�gitos: ");
	scanf("%d%d%d%d%d", &num_1, &centena, &resto_1, &dezena, &unidade);
	
/* Encontrando a soma de centena, dezena e unidade usa-se um scanf
para cada valor que eu quero receber, receber�s um s� valor, ent�o para
5(cinco) vari�veis eu irei usar o valor que eu recebi para o �nico scanf
*/

	centena = num_1 / 100;
	resto_1 = num_1 % 100;
	dezena = resto_1 / 10;
	unidade = num_1 % 10;
	
	soma_digitos = centena + dezena + unidade;
	printf("O valor de C + D + U ser� equivalente a %2d ", soma_digitos);
	system("PAUSE");
}
