#include <stdio.h>
#include <stdlib.h>

/* Leia o turno em que um aluno estuda, sendo M para Matutino, V para Vespertino
ou N para Noturno e escreva a mensagem "Bom Dia!", "Boa Tarde!" ou "Boa Noite!"
 ou "Valor Inv�lido!", conforme o caso.
 */
 
 int main()
 {
		char mensagem;
	
		printf("Escreva o turno em que Vin�cius estuda ADS: ");
		scanf("%s", &mensagem);
		
		if (mensagem == "M - Matutino" || mensagem == "m - matutino") {
			printf("Bom Dia! / n / n ");
		}else if (mensagem == "V - Vespertino" || mensagem == "v - vespertino") {
			printf("Boa Tarde! / n / n ");
		}else if (mensagem == "N - Noturno" || mensagem == "n - noturno") {
			printf("Boa Noite! / n / n ");
		}else {
			printf("Valor Inv�lido! / n / n ");
		}
}
