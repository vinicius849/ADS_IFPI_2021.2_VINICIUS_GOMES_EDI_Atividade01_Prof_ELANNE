#include <stdio.h>
#include <string.h>

/* Leia uma letra e verifique se a letra � "F" e escreva "F- Feminino" ou "M"
 escreva "M- Masculino", se n�o for nem F ou M, escreva "Sexo Inv�lido".
*/

int main()
{
	char sexo;
	
	printf("Digite aqui uma letra para indica��o dos sexos: ");
	scanf("%s", &sexo);
	
	if (sexo == "F" || sexo == "f") {
	printf("F - para FEMININO / n/ n");
	}
	else if (sexo == "M" || sexo == "m") {
	printf("M - para MASCULINO / n/ n");
	}else {
		printf("Sexo Inv�lido.");
	}

}

