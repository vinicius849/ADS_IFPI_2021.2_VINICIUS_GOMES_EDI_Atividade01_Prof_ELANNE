#include <stdio.h>
#include <stdlib.h>
#include <conio.h> 

/* Leia o pre�o de tr�s produtos e informe qual produto deve
ser comprado, sabendo que a decis�o � sempre pelo mais barato.
*/

main()
{
	float laranja, uva, maracuja;
	
	printf("Informe quanto custa a laranja: ");
	scanf("%f", &laranja);
	printf("Informe quanto custa a uva: ");
	scanf("%f", &uva);
	printf("Informe quanto custa o maracuja: ");
	scanf("%f", &maracuja);
	
	if (laranja <= 2.29 && uva > 6.00) {
		printf("Ent�o, levarei a laranja.");
	}else if (uva >= 5.42 && maracuja < 7.98) {
		printf("Ent�o, eu levarei a uva.");
	}else if (laranja >= 3.63 && maracuja >= 8.25) {
		printf("Ent�o, eu levarei a laranja.");
	}else {
		printf("Por falta de op��es, optei por fazer um delicioso e caro suco de maracuj�.");
	}
}
