#include <stdio.h>
#include <stdlib.h>

/* Escreva um programa que leia um n�mero inteiro e mostre 
uma mensagem indicando se este � positivo ou negativo.
*/

int main(int arge, char *argv[])
{

	int numero;
	
	printf("Digite aqui um n�mero qualquer? /t");
	scanf("%d", &numero);

	if (numero > 0)
	{
	printf("O n�mero dado � POSITIVO.");
	}
	else if (numero < 0)
	{
	printf("o n�mero dado � NEGATIVO.");
	}
	else 
	{
	printf("FIM DA QUEST�O.");
	system("PAUSE");
	}
}
	
