#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia uma velocidade em km/h, calcule e escreva essa velocidade 
em m/s.
*/

main()
{
	float vel_ms, vel_kmh;
	
	printf("Digite aqui a velocidade em m/s por gentileza: ");
	scanf("%f",&vel_ms);
	printf("Digite aqui a velocidad em km/h por gentileza: ");
	scanf("%f",&vel_kmh);
	
	vel_ms = (vel_kmh / 3.6);
	printf("A velocidade convertida ser� igual a %2f ",vel_ms,"metros por segundo");
	system("PAUSE");
}
