#include <stdio.h>

// Leia uma letra e verifique se a letra digitada � vogal ou consoante

int main()
{
	char letra;

	printf("Digite aqui uma letra do nosso alfabeto alfanum�rico portugu�s: ");
	scanf("%s", &letra);
	
	if (letra == "a" || letra == "e" || letra == "i" || letra == "o" || letra == "u" || letra == "A" || letra == "E" || letra == "I" || letra == "O" || letra == "U") {
		printf("� vogal / n / n");
	}else {
		printf("� consoante / n / n");
	}
}
