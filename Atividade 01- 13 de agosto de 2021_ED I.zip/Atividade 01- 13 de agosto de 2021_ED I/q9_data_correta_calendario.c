#include <stdio.h>

/* Leia uma data(dia, m�s, ano), verifique e escreva
se a data � ou n�o v�lida. Vale tamb�m para anos bissextos
*/

int main()
{
		int dia, mes, ano, data_valida;
		bool bissexto, mes_valido, dia_valido;
		
		printf("Digite aqui o dia: ");
		scanf("%d", &dia);
		printf("Digite aqui o m�s: ");
		scanf("%d", &mes);
		printf("Digite aqui o ano: ");
		scanf("%d", &ano);
		
// Descobrir se o ano � bissexto 

	if (ano % 4 == 0)
	{
		if (ano % 100 == 0)
		{
			if (ano % 400 == 0)
			{
			  bissexto = true;
			} else {
			  bissexto = false;
			}
		} else {
			bissexto = true;
		} else {
		bissexto = false;
		}
	}
		
// Verificar m�s

	if (mes <= 12)
	{
		mes_valido = true;
	}else{
		mes_valido = false;
	}
	
// verificar dia

	if (bissexto == true && mes == 2)
	{
		if (dia <= 29)
		{
			dia_valido = true;
		}else{
			dia_valido = false;
		}
	}else if(bissexto == false && mes == 2){
		 if (dia <= 28){
		 	 dia_valido = true;
		 }else{
		 	 dia_valido = false;
		}
		else if (mes == 4 || mes == 6 || mes == 9 || mes == 11){
			if (dia <= 30)
			{
			  dia_valido = true;
			}else{
			  dia_valido == false;
			}
			
		 if (mes_valido == true && di_valido == true)
		 {
			printf("A data � v�lida! /n/n");
		}else{
		    printf("A data n�o � valida! /n/n");
		}
		system("PAUSE");
		
}
	
