#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia 3(tr�s) n�meros, verifique e escreva o maior
entre os n�meros lidos.
*/

int main()
{
	int num_1, num_2, num_3, maior_deles;
	
	printf("Escreva 3(tr�s) n�meros: ");
	scanf("%d%d%d", &num_1, &num_2, &num_3);
	
	if (num_1 > num_2) {
			maior_deles = num_1;
	}else {
		maior_deles = num_2;
	}
	if (num_2 > num_3) {
		maior_deles = num_2;
	}else {
		maior_deles = num_3;
	}
	if (maior_deles > num_3) {
		printf("Ent�o, estabelecemos uma resposta comparativa de 3 n�meros. Logo n�mero 1 � maior que n�mero 3.")
    }else {
		printf("Caso acabe as chances de n�mero 1 e n�mero 2 serem maiores, n�mero 3 vai ser o maior.")
	}
	printf("A vers�o descrita acima para maior valor entre 3 n�meros � %d ", maior_deles);
	system("PAUSE");
}
