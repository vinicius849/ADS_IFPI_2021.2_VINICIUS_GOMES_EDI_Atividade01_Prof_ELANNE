#include <stdio.h>

/* Leia 1(um) n�mero de 2(dois) d�gitos, verifique e escreva se o algarismo
da dezena � ou n�o � igual ou diferente do algarismo da unidade.
*/

int main()
{
	int inteiro, dezena, unidade;
	
	printf("Digite aqui um n�mero de 2(dois) d�gitos quaisquer: ");
	scanf("%d", &inteiro);
	
	dezena = inteiro / 10;
	unidade = inteiro - (dezena * 10);
	
	if (dezena == unidade)
	{
		printf("Estes n�meros s�o iguais!/n/n");
	}
	else 
	{
		printf("Estes s�o diferentes /n/n");
	}
		system("PAUSE");
}
	
	
