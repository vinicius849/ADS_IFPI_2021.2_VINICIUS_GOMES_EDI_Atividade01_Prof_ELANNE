#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/* Leia um valor em horas e um valor em minutos, 
calcule e escreva o equivalente em minutos.
*/

main()
{
	int valor_hora, valor_minuto, valor_total;
	
	printf("Digite aqui um valor de horas: ");
	scanf("%d", &valor_hora);
	printf("Digite aqui um valor em minutos: ");
	scanf("%d", &valor_minuto);
	
	valor_total = (valor_hora * 60) + valor_minuto;
	printf("O total de minutos gastos foi %2d: ", valor_total);
	system("PAUSE");
}
